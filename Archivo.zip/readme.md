# Metin2-Web

## Introduction

Este proyecto web comprende registro, login, panel de usuario, itemshop, ranking, y muchas mas herramientas para el manejo de un servidor de metin2.

El back-end se realizo con el framework Laravel el cual incluye por defecto el framework bootstrap de css.



## IMAGES 

<img src="http://img.fenixzone.net/i/Wnq1oy9.jpeg" width="100%"/>
<hr>
<img src="http://img.fenixzone.net/i/rKkSVD5.jpeg" width="100%" />

## Installation

Instalacion en proceso de creacion de migraciones.