<?php $__env->startSection('content'); ?>
<div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">SHOP | TIENDA </h3>
  </div>
  <div class="panel-body">	
	<div class="row">
		<div class="col-md-12">
			<div class="col-md-3">
			 <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			 <a href="" style="width:100%; margin:1px !important;" class="btn btn-success btn-sm">
			 <?php echo e($categorias->name_categoria); ?></a>
			 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
			 </div>
			 <div class="col-md-9">
			<?php if($success): ?>
			    <div class="alert alert-success alert-block">
			        <button type="button" class="close" data-dismiss="alert">&times;</button>
			        <ul>
			          <?php echo e($success); ?>

			        </ul>
			    </div>
			 <?php endif; ?>
			  <?php $__currentLoopData = $articulo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<table class="table">
					<tr>
						<td rowspan="3"><img src="http://www.uslanmam.com/customavatars1/avatar533620_2.gif" width="500"></td>
						<td><b><u><?php echo e($articulos->name); ?></u></b></td>
						<td>Precio: <b><?php echo e($articulos->prices); ?></b> COINS</td>
					   </tr>
					   <tr>
						<td colspan="2"><b><u>Descripcion:</u></b> <?php echo e($articulos->content); ?></td>
					   </tr>
					   <tr >
						<td colspan="3" class="text-right"><a href="" class="btn btn-info btn-sm"><i class="fa fa-search" aria-hidden="true"></i> Ver detalles</a> <a href="/tienda-de-articulos/comprar/<?php echo e($articulos->vnum); ?>" class="btn btn-warning btn-primary btn-sm"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Comprar</a>
						</td>
					</tr>					
				</table>
			 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>				
			</div>
		</div>
	</div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>