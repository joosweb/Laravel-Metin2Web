<?php $__env->startSection('content'); ?>
<script type="text/javascript">
	$(function() {
    $('#favoritesModal').on("show.bs.modal", function (e) {
         $("#favoritesModalLabel").html($(e.relatedTarget).data('title'));
         $("#fav-title").html($(e.relatedTarget).data('title'));

         $vnum = $(e.relatedTarget).data('id');

          $.ajax({
	        url: $(e.relatedTarget).data('url'),
	        type: 'GET',
	        data: {'vnum':$vnum},
	        success: function(data){
	            $(".modal-body").html(data);
	         }
	    });
    });
});
</script>
<div class="modal fade" id="favoritesModal"
     tabindex="-1" role="dialog"
     aria-labelledby="favoritesModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close"
          data-dismiss="modal"
          aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"
        id="favoritesModalLabel">The Sun Also Rises</h4>
      </div>
      <div class="modal-body">

      </div>
      <div class="modal-footer">
        <button type="button"
           class="btn btn-default"
           data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">SHOP | TIENDA <span id="" style="float:right;">Monedas de Dragon: <?php echo e($coins); ?></span></h3>
  </div>
  <div class="panel-body">
	<div class="row">
		<div class="col-md-12">
			<div class="col-md-3">
			 <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			 <a href="/tienda-de-articulos/categoria/<?php echo e($categorias->classid); ?>" style="width:100%; margin:1px !important;" class="btn btn-success btn-sm">
			 <?php echo e($categorias->classname); ?></a>
			 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			 </div>
			 <div class="col-md-9">
			 <?php if($mensaje): ?>
			    <div class="alert alert-<?php echo e($mensaje[1]); ?> alert-block">
			        <button type="button" class="close" data-dismiss="alert">&times;</button>
			        <ul>
			          <i class="fa fa-check-square-o" aria-hidden="true"></i> <?php echo e($mensaje[0]); ?>

			        </ul>
			    </div>
			  <?php endif; ?>
			  <div class="panel panel-default" style="margin-top:-1px;">
				  <div class="panel-body">
				     <?php $__currentLoopData = $articulo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					 <table class="table">
						<tr>
							<td rowspan="3"><img src="http://www.uslanmam.com/customavatars1/avatar533620_2.gif" width="500"></td>
							<td><b><u><?php echo e($articulos->name); ?></u></b></td>
							<td align="right">Precio: <b><?php echo e($articulos->prices); ?></b> COINS</td>
						   </tr>
						   <tr>
							<td colspan="2"><b><u>Descripcion:</u></b> <?php echo e($articulos->content); ?></td>
						   </tr>
						   <tr >
							<td colspan="3" class="text-right"><button type="button" class="btn btn-info btn-sm"  data-toggle="modal" data-id="<?php echo e($articulos->vnum); ?>" data-title="<?php echo e($articulos->name); ?>" data-target="#favoritesModal" data-url="<?php echo e(URL::route('getLocation')); ?>"><i class="fa fa-search" aria-hidden="true"></i> Ver detalles</button>
							 <a href="/tienda-de-articulos/<?php echo e($articulos->vnum); ?>/comprar/" class="btn btn-warning btn-primary btn-sm"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Comprar</a>
							</td>
						</tr>
					</table>
				 	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  </div>
				</div>
				<?php echo e($articulo->render()); ?>

			</div>
		 </div>
	  </div>
    </div>
 </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>